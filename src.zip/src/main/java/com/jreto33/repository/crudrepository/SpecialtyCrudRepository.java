package com.jreto33.repository.crudrepository;

import com.jreto33.modelo.SpecialtyModel;
import org.springframework.data.repository.CrudRepository;

public interface SpecialtyCrudRepository extends CrudRepository<SpecialtyModel, Integer> {
}
