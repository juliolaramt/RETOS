package com.jreto33.repository.crudrepository;

import com.jreto33.modelo.ScoreModel;
import org.springframework.data.repository.CrudRepository;

public interface ScoreCrudRepository extends CrudRepository<ScoreModel, Integer> {
}
