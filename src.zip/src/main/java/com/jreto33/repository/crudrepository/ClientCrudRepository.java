package com.jreto33.repository.crudrepository;

import com.jreto33.modelo.ClientModel;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<ClientModel, Integer> {

}
