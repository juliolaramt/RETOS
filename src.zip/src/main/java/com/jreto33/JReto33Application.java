package com.jreto33;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JReto33Application {

    public static void main(String[] args) {
        SpringApplication.run(JReto33Application.class, args);
    }

}
