package com.jreto33;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JReto33ApplicationTests {

    @Test
    void contextLoads() {
    }

}
